Ubisoft DATA Tool [PC] - Alpha 1
Coded by Delutto - Tribo Gamer Brasil 2018
www.tribogamer.com

1 - Usage

 1.1 - Parameters: [GameCode] [option] <File.data> <OutputFolder>
                   GameCode: 1 = Assassin's Creed
                             2 = Assassin's Creed II
                             3 = Assassin's Creed Brotherhood
                             4 = Assassin's Creed Revelations
                             5 = Assassin's Creed III
                             6 = Assassin's Creed Liberation HD
                             7 = Assassin's Creed IV Black Flag
                             8 = Assassin's Creed Rogue
                             9 = Assassin's Creed Unity
                             10 = Assassin's Creed Syndicate
                             11 = Assassin's Creed Origins
                             12 = Assassin's Creed Odyssey
                             13 = For Honor (Not implemented yet)
                             14 = Prince of Persia
                             15 = Prince of Persia The Forgotten Sands
                             16 = Shaun White Snowboarding
                             17 = STEEP (Not implemented yet)
                             18 = Tom Clancy's Ghost Recon Wildlands
                             19 = Tom Clancy's Rainbow Six Siege
							 
				   Options: -e = Export Files
                            -i = Import Files
                            -h = This Help
		 
 1.2 - Export: -e
       Ubisoft_DATA_Tool.exe 7 -e Game_Bootstrap_Settings.data Game_Bootstrap_Settings
 
 1.3 - Import: -i (Point to original file)
       Ubisoft_DATA_Tool.exe 7 -i Game_Bootstrap_Settings.data Game_Bootstrap_Settings
	   Will be created a "Game_Bootstrap_Settings.data.NEW" file.
	   
 1.4 - Or just run the tool from executable, a dialog option will be showed.

 
2 - Notes

 2.1 - Both options use the same parameters order, because the tool need some unknown
       infos from original DATA file to create a new one.

	   
3 - Known Bugs

  - Game Prince of Persia The Forgotten Sands crash with repacked data file.

  
4 - Updates

  Alpha 1 - 12/30/2018
   - BugFix: Open File Dialog without file extension filter.
   - BugFix: Compressed blocks with the same size of decompressed data, making the game think that are a uncompressed blocks.
   - BugFix: Import function getting a wrong input filename, copying the original data instead the exported file.
   
  Alpha 0 - 12/29/2018
   - First alpha release.
   