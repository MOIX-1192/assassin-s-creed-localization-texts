Ubisoft FORGE Tool
Coded by Delutto - Tribo Gamer Brasil 2019
www.tribogamer.com

1 - Usage

 1.1 - Parameters: [option] <File.forge> <OutputFolder>
				   Options: -e = Export Files
                            -i = Import Files
                            -h = This Help
		 
 1.2 - Export: -e
       Ubisoft_FORGE_Tool.exe -e DataPC.forge DataPC
 
 1.3 - Import: -i (Point to original file)
       Ubisoft_FORGE_Tool.exe -i DataPC.forge DataPC
	   Will be created a "DataPC.forge.NEW" file.
	   
 1.4 - Or just run the tool from executable, a dialog option will be showed.

 
2 - Notes

 2.1 - Both options use the same parameters order, because the tool need some
       unknown infos from original FORGE file to create a new one.

	   
3 - Updates

  - None...